﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_ShowLeaderboardsUIAction : FsmStateAction {

		
		public override void Reset() {
			
		}


		public override void OnEnter() {
			GameCenterManager.ShowLeaderboards();
			Finish();
		}

	}
}

