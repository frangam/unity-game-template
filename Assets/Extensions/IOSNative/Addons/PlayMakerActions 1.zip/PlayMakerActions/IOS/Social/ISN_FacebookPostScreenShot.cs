using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_FacebookPostScreenShot : FsmStateAction {

		public FsmString message;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			IOSSocialManager.OnFacebookPostResult += HandleOnFacebookPostResult;
	

	

			ISN_ScreehSotPostTask task  = new GameObject("ScreehSotPostTask").AddComponent<ISN_ScreehSotPostTask>();
			task.type = "FB";
			task.msg = message.Value;

		}


		public override void Reset() {
			base.Reset();
			message   = "Message Text";

		}

		void HandleOnFacebookPostResult (ISN_Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			IOSSocialManager.OnFacebookPostResult -= HandleOnFacebookPostResult;
			Finish();
		}
	}
	
}


