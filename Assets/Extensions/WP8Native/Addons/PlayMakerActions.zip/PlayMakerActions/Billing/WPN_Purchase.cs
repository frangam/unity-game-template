using UnityEngine;
using UnionAssets.FLE;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("WP8 Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class WPN_Purchase : FsmStateAction {


		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;

		[Tooltip("Event fired when Store Kit initlization is failed")]
		public FsmEvent failEvent;


		[Tooltip("Purhase product Id")]
		public FsmString ProductID  = "";

	

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			


			WP8InAppPurchasesManager.instance.addEventListener (WP8InAppPurchasesManager.PRODUCT_PURCHASE_FINISHED, OnProductPurchased);
			WP8InAppPurchasesManager.instance.purchase(ProductID.Value);
			
		}

		private void OnProductPurchased(CEvent e) {
			WP8PurchseResponce result = e.data as WP8PurchseResponce;

			if(result.IsSuccses) {
				OnPurchase();
			} else {
				OnFailed();
			}

		}




		private void OnPurchase() {
			WP8InAppPurchasesManager.instance.removeEventListener (WP8InAppPurchasesManager.PRODUCT_PURCHASE_FINISHED, OnProductPurchased);

			Fsm.Event(successEvent);
			Finish();

		}

		private void OnFailed() {
			WP8InAppPurchasesManager.instance.removeEventListener (WP8InAppPurchasesManager.PRODUCT_PURCHASE_FINISHED, OnProductPurchased);

			Fsm.Event(failEvent);
			Finish();

		}
		
	}
}
