﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("WP8 Native  - Pop-ups")]
	public class WPN_DialogPopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message; 


		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public WP8DialogResult ResultInEditor = WP8DialogResult.YES;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			WP8Dialog popup = WP8Dialog.Create(title.Value, message.Value);

			popup.addEventListener(BaseEvent.COMPLETE, OnComplete);
			
		}

		
		public override void Reset() {
			base.Reset();
			
			title =  "Dialog title";
			message   = "Dialog message";

			
		}


		private void OnComplete(CEvent e) {
			
			//romoving listner
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, OnComplete);
			
			//parsing result
			ParseResult((WP8DialogResult)e.data);
		}


		private void ParseResult(WP8DialogResult res) {
			switch(res) {
			case WP8DialogResult.YES:
				Fsm.Event(yesEvent);
				break;
			case WP8DialogResult.NO:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


